package cn.aps.boot.logs.core;

import cn.aps.boot.logs.api.Logger;

/**
 * @Description : 抽象logger实现
 * @Author : lishirui
 * @Date ：2025/3/27 19:22
 */
public abstract class AbstractLogger implements Logger {
    // 输出日志格式
    String linkLogPattern = "%d{yyyy-MM-dd HH:mm:ss} [%t] %-5level %logger{36} - %msg%n";

    protected void link() {

    }


}
