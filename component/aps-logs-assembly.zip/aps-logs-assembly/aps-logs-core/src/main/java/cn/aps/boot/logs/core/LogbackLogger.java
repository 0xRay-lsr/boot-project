package cn.aps.boot.logs.core;

/**
* @Description : 基于logback实现
* @Author : lishirui
* @Date ：2025/3/27 16:45
*/
public class LogbackLogger extends AbstractLogger {
   private final org.slf4j.Logger logger;

   public LogbackLogger(Class<?> clazz) {
       this.logger = org.slf4j.LoggerFactory.getLogger(clazz);
   }
   public LogbackLogger(String name) {
       this.logger = org.slf4j.LoggerFactory.getLogger(name);
   }
}
