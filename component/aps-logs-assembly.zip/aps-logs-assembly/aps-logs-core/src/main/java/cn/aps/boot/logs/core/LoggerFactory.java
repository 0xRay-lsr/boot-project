package cn.aps.boot.logs.core;

import cn.aps.boot.logs.api.Logger;
import cn.aps.boot.logs.api.constants.LogCategoryConstant;

/**
 * @Description : 日志获取工厂
 * @Author : lishirui
 * @Date ：2025/3/27 16:54
 */
public class LoggerFactory {
    /**
     * 启动日志logger
     *
     * @return
     */
    public static Logger getBootLogger(Class<?> clazz) {
        return getLogger(LogCategoryConstant.APS_BOOT + clazz.getName());
    }

    /**
     * 应用日志
     *
     * @param clazz
     * @return
     */
    public static Logger getAppLogger(Class<?> clazz) {
        return getLogger(LogCategoryConstant.APS_APP + clazz.getName());
    }

    /**
     * 定时任务日志
     *
     * @param clazz
     * @return
     */
    public static Logger getTimerLogger(Class<?> clazz) {
        return getLogger(LogCategoryConstant.APS_TIMER + clazz.getName());
    }

    /**
     * 中间件日志
     *
     * @param clazz
     * @return
     */
    public static Logger getMidwareLogger(Class<?> clazz) {
        return getLogger(LogCategoryConstant.APS_MIDWARE + clazz.getName());
    }

    /**
     * 性能日志
     *
     * @param clazz
     * @return
     */
    public static Logger getProfileLogger(Class<?> clazz) {
        return getLogger(LogCategoryConstant.APS_PROFILE + clazz.getName());
    }

    public static Logger getTraceLogger(Class<?> clazz) {
        return getLogger(LogCategoryConstant.APS_TRACE + clazz.getName());
    }

    /**
     * 批量日志
     *
     * @param clazz
     * @return
     */
    public static Logger getBatchLogger(Class<?> clazz) {
        return getLogger(LogCategoryConstant.APS_BATCH + clazz.getName());
    }

    /**
     * 告警日志
     *
     * @return
     */
    public static Logger getAlertLogger() {
        return getLogger(LogCategoryConstant.APS_ALERT);
    }

    /**
     * 通讯日志
     *
     * @return
     */
    public static Logger getLinkLogger() {
        return getLogger(LogCategoryConstant.APS_LINKS);
    }

    /**
     * 慢sql 日志
     *
     * @return
     */
    public static Logger getShowSqlLogger() {
        return getLogger(LogCategoryConstant.APS_SLOWSQL);
    }

    /**
     * sql日志
     *
     * @return
     */
    public static Logger getSqlLogger() {
        return getLogger(LogCategoryConstant.APS_SQL);
    }


    /**
     * 获取logger
     *
     * @param loggerName 指定logname 输出 如 ：com.example.service
     * @return logger 对象
     */
    public static Logger getLogger(String loggerName) {
        if (isLog4j2Available()) {
            return new Log4j2Logger(loggerName);
        } else if (isLogbackAvailable()) {
           return new LogbackLogger(loggerName);
        } else {
            throw new UnsupportedOperationException("Neither Log4j2 nor Logback is available!");
        }
    }

    /**
     * 获取logger
     *
     * @param clazz
     * @return
     */
    public static Logger getLogger(Class<?> clazz) {
        if (isLog4j2Available()) {
            return new Log4j2Logger(clazz);
        } else if (isLogbackAvailable()) {
           return new LogbackLogger(clazz); 
        } else {
            throw new UnsupportedOperationException("Neither Log4j2 nor Logback is available!");
        }
    }

    private static boolean isLog4j2Available() {
        try {
            // 尝试加载 Log4j2 的相关类
            Class.forName("org.apache.logging.log4j.core.Logger");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    private static boolean isLogbackAvailable() {
        try {
            // 尝试加载 Logback 的相关类
            Class.forName("ch.qos.logback.classic.Logger");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

}
