package cn.aps.boot.logs;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}